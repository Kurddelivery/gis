---
name: Custom issue template
about: Other issues
title: ''
labels: ''
assignees: ''

---

_Please bear in mind that I have a limited amount of time, and as such may not be able to address your issue right away. If you find the library useful, please consider Sponsoring the project. Bugs & feature requests from Sponsors will be treated with priority._

If you are reporting a bug or asking for a feature, please use the **Bug report** or **Feature request** templates. Failure to do so may result in your issue being closed and you will be asked to fill in the relevant template.
